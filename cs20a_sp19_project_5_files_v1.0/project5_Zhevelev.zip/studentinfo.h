#ifndef STUDENTINFO_H
#define STUDENTINFO_H
#include<string>

//Replace "Your Name" and "Your ID#";
namespace StudentInfo {
	std::string name() { return "Dmitriy Zhevelev"; }
	std::string id() { return "1617621"; }
};

#endif