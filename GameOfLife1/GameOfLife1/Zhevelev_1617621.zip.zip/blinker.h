#ifndef BLINKER_H
#define BLINKER_H

#include "life.h"
class Blinker : public Life {
public:

	// Constructor/destructor
	Blinker(int r, int c);
	~Blinker();
};

#endif BLINKER_H